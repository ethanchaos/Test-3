#!/usr/bin/env python3
"""
setup.py — Chaos-Org SNI Scanner installer.

Global commands after `pip install -e .` or `pip install .`:
  scanner   |   chaos-org   |   s-scanner
"""

from setuptools import setup, find_packages
from pathlib import Path

setup(
    name="chaos-org-sni-scanner",
    version="1.1.0",
    description="SSL/TLS SNI Scanner by Chaos Configurations",
    author="EthanChaosS",
    packages=find_packages(),          # discovers chaos_org/
    package_data={
        "chaos_org": [
            "dashboard.html",
            "dashboard/index.html",
        ],
    },
    install_requires=[
        "requests>=2.31.0",
        "urllib3>=2.0.0",
        "websockets>=12.0",
    ],
    entry_points={
        "console_scripts": [
            "scanner=chaos_org.main:main",
            "chaos-org=chaos_org.main:main",
            "s-scanner=chaos_org.main:main",
        ],
    },
    python_requires=">=3.8",
)
