#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Chaos-Org SNI Scanner — global installer
# Creates system-wide launch commands: scanner | chaos-org | s scanner
# ─────────────────────────────────────────────────────────────────────────────
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python3}"

echo ""
echo "  Chaos-Org · SNI Scanner Installer"
echo "  ───────────────────────────────────"
echo ""

# 1. Install Python package (editable so source edits are live)
echo "  [1/3] Installing Python dependencies and package …"
"$PYTHON" -m pip install -e "$SCRIPT_DIR" --quiet
echo "        Done."

# 2. Drop a 's scanner' wrapper (handles the space in the command name)
#    Try /usr/local/bin first, fall back to ~/.local/bin
install_wrapper() {
    local target_dir="$1"
    local wrapper="$target_dir/s scanner"  # file name with a space — valid on Linux/macOS

    if [ -w "$target_dir" ] || sudo -n true 2>/dev/null; then
        local use_sudo=""
        [ ! -w "$target_dir" ] && use_sudo="sudo"

        $use_sudo tee "$target_dir/s scanner" > /dev/null << 'WRAPPER'
#!/usr/bin/env bash
exec scanner "$@"
WRAPPER
        $use_sudo chmod +x "$target_dir/s scanner"
        echo "        Installed 's scanner' → $target_dir"
        return 0
    fi
    return 1
}

echo "  [2/3] Creating 's scanner' alias …"
if ! install_wrapper "/usr/local/bin" 2>/dev/null; then
    mkdir -p "$HOME/.local/bin"
    install_wrapper "$HOME/.local/bin" || echo "        Warning: could not install 's scanner' alias."
fi

# 3. Remind user to add ~/.local/bin to PATH if not already there
echo "  [3/3] Verifying PATH …"
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo ""
    echo "  ⚠  Add this to your shell config (~/.bashrc / ~/.zshrc):"
    echo "     export PATH=\"\$HOME/.local/bin:\$PATH\""
fi

echo ""
echo "  ✓  Installation complete! You can now run:"
echo ""
echo "     scanner       — start the SNI Scanner"
echo "     chaos-org     — start the SNI Scanner"
echo "     s scanner     — start the SNI Scanner"
echo ""
