#!/usr/bin/env python3
"""
main.py — Chaos-Org SNI Scanner entry point.
Delegates everything to the chaos_org package so all modules resolve correctly
whether the tool is run locally (python main.py) or as a global command
installed via pip (scanner / chaos-org / s-scanner).
"""
from chaos_org.main import main

if __name__ == "__main__":
    main()
