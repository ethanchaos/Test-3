#!/usr/bin/env python3
"""
gui_server.py
GUI Mode backend — enhanced for Chaos-Org v1.1.0.

Serves the dashboard over plain HTTP and bridges it to the SAME SNIVPNTester
engine used by CLI mode via WebSocket.  CLI output is mirrored with
color-coded log lines (spec §5).
"""

import asyncio
import json
import socket
import sys
import os
import threading
import http.server
from pathlib import Path

import websockets

from .sni_core import SNIVPNTester

HTTP_PORT = 8000
WS_PORT   = 8001

STATIC_DIR = Path(__file__).parent  # always the chaos_org/ package dir

# ── Color helpers (mirrors cli_mode) ─────────────────────────────────────────

class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    CYAN    = "\033[96m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    RED     = "\033[91m"
    WHITE   = "\033[97m"
    GRAY    = "\033[90m"


def _supports_color() -> bool:
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


_USE_COLOR = _supports_color()


def _c(text: str, *codes: str) -> str:
    return ("".join(codes) + text + C.RESET) if _USE_COLOR else text


def log_info(msg: str):  print(_c("[INFO]  ", C.BLUE,   C.BOLD) + msg, flush=True)
def log_ok(msg: str):    print(_c("[ OK ]  ", C.GREEN,  C.BOLD) + msg, flush=True)
def log_warn(msg: str):  print(_c("[WARN]  ", C.YELLOW, C.BOLD) + msg, flush=True)
def log_err(msg: str):   print(_c("[ERROR] ", C.RED,    C.BOLD) + msg, flush=True)


# ── Scan session ──────────────────────────────────────────────────────────────

class ScanSession:
    """Holds the tester engine + scan state for a single browser connection."""

    def __init__(self, send_fn, loop):
        self.tester          = SNIVPNTester()
        self.send_fn         = send_fn
        self.loop            = loop
        self.scan_thread     = None
        self._stop_requested = False

    def stop_flag(self):
        return self._stop_requested

    def request_stop(self):
        self._stop_requested = True

    def _emit(self, message: dict):
        """Thread-safe emit from the worker thread back into the asyncio loop."""
        asyncio.run_coroutine_threadsafe(self.send_fn(message), self.loop)

    def _progress_callback(self, result, completed, total):
        status = result["status"]
        sni    = result["sni"]
        # Mirror to terminal with colour
        if status == "YES":
            log_ok(f"[{completed}/{total}] {_c(sni, C.WHITE, C.BOLD)} — {_c('TUNNEL OK', C.GREEN, C.BOLD)}")
        else:
            log_warn(f"[{completed}/{total}] {sni} — {_c('no tunnel', C.GRAY)}")

        self._emit({
            "type": "result",
            "result": {
                "sni":    sni,
                "conn":   bool(result["connection_test"]),
                "search": bool(result["search_test"]),
                "rate":   result["overall_success"],
                "status": status,
            },
            "completed": completed,
            "total":     total,
        })

    def run_scan(self, hosts, max_workers, batch_size):
        self._stop_requested = False
        total = len(hosts)

        if total > 10_000:
            self.tester.setup_large_scale_mode()
            log_warn(f"Large-scale mode activated ({total:,} hosts).")

        log_info(f"Scan started — {total:,} hosts | workers={max_workers} | batch={batch_size}")
        self._emit({"type": "started", "total": total})

        try:
            self.tester.test_multiple_sni(
                hosts,
                max_workers=max_workers,
                batch_size=batch_size,
                progress_callback=self._progress_callback,
                stop_flag=self.stop_flag,
            )
        except Exception as e:
            log_err(f"Scan error: {e}")
            self._emit({"type": "error", "message": str(e)})
        finally:
            successful = self.tester.successful_tunnels
            total_done = self.tester.total_tests
            if self._stop_requested:
                log_warn(f"Scan stopped by user — {successful}/{total_done} positive so far.")
            else:
                log_ok(f"Scan finished — {successful}/{total_done} tunnels found.")
            self._emit({
                "type":               "finished",
                "stopped":            self._stop_requested,
                "successful_tunnels": successful,
                "total_tests":        total_done,
            })

    def start_scan_async(self, hosts, max_workers, batch_size):
        if self.scan_thread and self.scan_thread.is_alive():
            return False
        self.scan_thread = threading.Thread(
            target=self.run_scan,
            args=(hosts, max_workers, batch_size),
            daemon=True,
        )
        self.scan_thread.start()
        return True


# ── WebSocket handler ─────────────────────────────────────────────────────────

async def handle_client(websocket):
    loop = asyncio.get_running_loop()

    async def send_fn(message: dict):
        try:
            await websocket.send(json.dumps(message))
        except websockets.exceptions.ConnectionClosed:
            pass

    session = ScanSession(send_fn, loop)
    log_info("Dashboard client connected.")

    try:
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue

            action = msg.get("action")

            if action == "start_scan":
                hosts       = msg.get("hosts", [])
                max_workers = int(msg.get("max_workers", 10) or 10)
                batch_size  = int(msg.get("batch_size", 10_000) or 10_000)

                if not hosts:
                    log_warn("Start-scan request received with no hosts.")
                    await send_fn({"type": "error", "message": "No SNI hosts provided."})
                    continue

                started = session.start_scan_async(hosts, max_workers, batch_size)
                if not started:
                    log_warn("Scan already running — ignoring duplicate start request.")
                    await send_fn({"type": "error", "message": "A scan is already running."})

            elif action == "stop_scan":
                log_warn("Stop requested by dashboard user.")
                session.request_stop()

            elif action == "ping":
                await send_fn({"type": "pong"})

    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        session.request_stop()
        log_info("Dashboard client disconnected.")


# ── HTTP server ───────────────────────────────────────────────────────────────

class QuietHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Serves the static dashboard with minimal terminal noise."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def log_message(self, fmt, *args):
        # Only log non-200 responses so errors surface
        if args and str(args[1]) != "200":
            log_warn(f"HTTP {args[1]} — {args[0]}")


def start_http_server():
    handler = QuietHTTPRequestHandler
    httpd   = http.server.ThreadingHTTPServer(("0.0.0.0", HTTP_PORT), handler)
    thread  = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


async def start_ws_server():
    async with websockets.serve(handle_client, "0.0.0.0", WS_PORT):
        await asyncio.Future()   # run forever


def run_gui():
    hostname = socket.gethostname()
    local_ip = get_local_ip()

    start_http_server()

    print()
    print(_c("  Chaos-Org  ·  SNI Scanner  ·  GUI Mode", C.CYAN, C.BOLD))
    print(_c("  Created by Ethan Chaos  ·  Chaos Configurations", C.GRAY))
    print(_c("  " + "─" * 46, C.GRAY))
    print()
    log_ok("Dashboard is live. Open one of these URLs in your browser:")
    print()
    for url in [
        f"http://127.0.0.1:{HTTP_PORT}/dashboard.html",
        f"http://localhost:{HTTP_PORT}/dashboard.html",
        f"http://{local_ip}:{HTTP_PORT}/dashboard.html",
        f"http://{hostname}:{HTTP_PORT}/dashboard.html",
    ]:
        print("  " + _c("→ ", C.CYAN, C.BOLD) + _c(url, C.WHITE, C.BOLD))

    print()
    log_info(f"WebSocket bridge  →  ws://0.0.0.0:{WS_PORT}")
    log_info("Press Ctrl+C to stop the server.")
    print()

    try:
        asyncio.run(start_ws_server())
    except KeyboardInterrupt:
        log_warn("Server stopped by user. Goodbye.")


if __name__ == "__main__":
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    socket.setdefaulttimeout(30)
    run_gui()
