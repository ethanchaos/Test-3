#!/usr/bin/env python3
"""
cli_mode.py
CLI Mode — original terminal workflow, enhanced with color-coded output.
Scanning/testing logic (sni_core.py) is untouched.
"""

import socket
import sys
import os

from .sni_core import SNIVPNTester

# ── Color helpers ──────────────────────────────────────────────────────────────

class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    CYAN    = "\033[96m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    RED     = "\033[91m"
    WHITE   = "\033[97m"
    GRAY    = "\033[90m"


def _supports_color() -> bool:
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


_USE_COLOR = _supports_color()


def _c(text: str, *codes: str) -> str:
    return ("".join(codes) + text + C.RESET) if _USE_COLOR else text


# ── Logging shortcuts (spec §5) ────────────────────────────────────────────────

def log_info(msg: str):    print(_c("[INFO]   ", C.BLUE,   C.BOLD) + msg)
def log_ok(msg: str):      print(_c("[ OK ]   ", C.GREEN,  C.BOLD) + msg)
def log_warn(msg: str):    print(_c("[WARN]   ", C.YELLOW, C.BOLD) + msg)
def log_err(msg: str):     print(_c("[ERROR]  ", C.RED,    C.BOLD) + msg)


def _divider(char="─", width=52):
    print(_c(char * width, C.GRAY))


def _section(title: str):
    _divider()
    print(_c(f"  {title}", C.CYAN, C.BOLD))
    _divider()


def _menu():
    print()
    _c_opt = lambda n, label: (
        print(_c(f"  [{n}]", C.CYAN, C.BOLD) + "  " + label)
    )
    print(_c("  Options", C.WHITE, C.BOLD))
    _divider("·")
    _c_opt("1", "Test single SNI")
    _c_opt("2", "Test multiple SNIs from file")
    _c_opt("3", "View results summary")
    _c_opt("4", "View successful URLs only")
    _c_opt("5", "Save results to file")
    _c_opt("6", "Exit")
    print()


# ── Main CLI entrypoint ────────────────────────────────────────────────────────

def run_cli():
    tester = SNIVPNTester()

    print()
    print(_c("  Chaos-Org  ·  SNI Scanner CLI", C.CYAN, C.BOLD))
    print(_c("  Created by Ethan Chaos  ·  Chaos Configurations", C.GRAY))
    _divider()

    while True:
        _menu()
        choice = input(_c("  → ", C.CYAN, C.BOLD)).strip()

        if choice == "1":
            _section("Single SNI Test")
            sni = input(_c("  SNI host: ", C.WHITE)).strip()
            if sni:
                log_info(f"Testing {_c(sni, C.WHITE, C.BOLD)} …")
                result = tester.test_sni_comprehensive(sni)
                tester.display_result(result)
                if result.get("overall_success", 0) > 0:
                    log_ok("Test completed — result is positive.")
                else:
                    log_warn("Test completed — no tunnel detected.")
            else:
                log_warn("No SNI host entered.")

        elif choice == "2":
            _section("Bulk SNI Test from File")
            filename = input(_c("  File path: ", C.WHITE)).strip()
            if filename:
                sni_list = tester.load_sni_from_file(filename)
                if sni_list:
                    count = len(sni_list)
                    log_info(f"Loaded {_c(str(count), C.WHITE, C.BOLD)} SNI hosts from file.")

                    if count > 10_000:
                        tester.setup_large_scale_mode()
                        log_warn(f"Large-scale mode activated ({count:,} hosts).")

                    raw_w = input(_c("  Concurrent workers (default 10): ", C.WHITE)).strip()
                    raw_b = input(_c("  Batch size (default 10000):       ", C.WHITE)).strip()
                    max_workers = int(raw_w) if raw_w.isdigit() else 10
                    batch_size  = int(raw_b) if raw_b.isdigit() else 10_000

                    log_info(f"Starting scan — workers={max_workers}, batch={batch_size} …")
                    tester.test_multiple_sni(sni_list, max_workers, batch_size)
                    log_ok("Scan complete.")
                else:
                    log_err("No valid SNI hosts found in the file.")
            else:
                log_warn("No file path entered.")

        elif choice == "3":
            _section("Results Summary")
            if tester.large_scale_mode or tester.results:
                tester.display_summary()
            else:
                log_warn("No test results available. Run a scan first.")

        elif choice == "4":
            _section("Successful URLs")
            if tester.large_scale_mode or tester.results:
                save = input(_c("  Save to file? [y/N]: ", C.WHITE)).strip().lower()
                out  = None
                if save == "y":
                    out = input(_c("  Output filename (default: successful_urls.txt): ", C.WHITE)).strip()
                    out = out or "successful_urls.txt"
                tester.display_successful_urls(out)
                if out:
                    log_ok(f"Saved to {_c(out, C.WHITE, C.BOLD)}")
            else:
                log_warn("No test results available. Run a scan first.")

        elif choice == "5":
            _section("Save Results")
            if tester.large_scale_mode or tester.results:
                fname = input(_c("  Output filename (default: sni_test_results.txt): ", C.WHITE)).strip()
                fname = fname or "sni_test_results.txt"
                tester.save_results_to_file(fname)
                log_ok(f"Results saved to {_c(fname, C.WHITE, C.BOLD)}")
            else:
                log_warn("No test results to save.")

        elif choice == "6":
            log_info("Exiting Chaos-Org SNI Scanner. Goodbye.")
            break

        else:
            log_err("Invalid choice. Please enter a number between 1 and 6.")


if __name__ == "__main__":
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    socket.setdefaulttimeout(30)
    run_cli()
