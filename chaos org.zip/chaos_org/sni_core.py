#!/usr/bin/env python3
"""
sni_core.py
SNI / VPN-tunnel testing engine.

This module contains the ORIGINAL scanning and testing logic, unchanged,
extracted from the original single-file script so it can be shared
identically between CLI mode and GUI mode. Do not modify the test_* methods
below — both modes depend on them producing identical results.
"""

import requests
import socket
import ssl
import time
from urllib.parse import urlparse
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import json
from collections import deque
import logging


class SNIVPNTester:
    def __init__(self, max_memory_results=10000):
        self.results = deque(maxlen=max_memory_results)  # Use deque to limit memory usage
        self.successful_tunnels = 0
        self.total_tests = 0
        self.large_scale_mode = False
        self.results_file = None
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/537.36'
        ]

        # Setup logging for large scale operations
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('sni_test.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def get_user_agent(self):
        return random.choice(self.user_agents)

    def setup_large_scale_mode(self, results_filename="large_scale_results.jsonl"):
        """Setup for large scale testing with file-based results storage"""
        self.large_scale_mode = True
        self.results_file = results_filename
        # Initialize or clear the results file
        open(self.results_file, 'w').close()
        self.logger.info(f"Large scale mode enabled. Results will be saved to: {self.results_file}")

    def save_result_to_file(self, result):
        """Save individual result to file for large scale testing"""
        if self.large_scale_mode and self.results_file:
            with open(self.results_file, 'a') as f:
                f.write(json.dumps(result) + '\n')

    def load_results_from_file(self, filter_successful=False):
        """Load results from file with optional filtering"""
        if not self.results_file or not os.path.exists(self.results_file):
            return []

        results = []
        with open(self.results_file, 'r') as f:
            for line in f:
                if line.strip():
                    result = json.loads(line.strip())
                    if not filter_successful or result.get('status') == 'YES':
                        results.append(result)
        return results

    def test_sni_connection(self, sni_host, target_url="https://www.google.com"):
        """
        Test SNI tunneling by establishing SSL connection with specific SNI
        """
        try:
            # Parse the target URL
            parsed = urlparse(target_url)
            hostname = parsed.hostname or "www.google.com"
            port = parsed.port or 443

            # Create socket connection
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((hostname, port))

            # Create SSL context with SNI
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE

            # Wrap socket with SSL and specified SNI
            ssl_sock = context.wrap_socket(sock, server_hostname=sni_host)

            # Try to perform SSL handshake
            ssl_sock.do_handshake()

            # Test HTTP request through the tunnel
            request = f"GET / HTTP/1.1\r\nHost: {hostname}\r\nUser-Agent: {self.get_user_agent()}\r\nConnection: close\r\n\r\n"
            ssl_sock.send(request.encode())

            # Receive response
            response = b""
            while True:
                try:
                    data = ssl_sock.recv(4096)
                    if not data:
                        break
                    response += data
                except socket.timeout:
                    break

            ssl_sock.close()
            sock.close()

            # Check if response indicates success
            if b"200 OK" in response or b"HTTP/1.1 200" in response:
                return True, "SNI tunneling successful"
            else:
                return True, "Connection established but unexpected response"

        except ssl.SSLError as e:
            return False, f"SSL Error: {str(e)}"
        except socket.timeout:
            return False, "Connection timeout"
        except ConnectionRefusedError:
            return False, "Connection refused"
        except Exception as e:
            return False, f"Error: {str(e)}"

    def test_google_search(self, sni_host):
        """
        Test actual Google search through the SNI tunnel
        """
        try:
            headers = {
                'User-Agent': self.get_user_agent(),
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
            }

            # Test with requests session
            session = requests.Session()
            session.headers.update(headers)

            # Test search query
            search_url = "https://www.google.com/search"
            params = {'q': 'test vpn sni working'}

            response = session.get(search_url, params=params, timeout=10, verify=False)

            if response.status_code == 200 and 'search' in response.text.lower():
                return True, "Google search successful"
            else:
                return False, f"Google search failed with status: {response.status_code}"

        except requests.exceptions.RequestException as e:
            return False, f"Request failed: {str(e)}"
        except Exception as e:
            return False, f"Search test error: {str(e)}"

    def test_sni_comprehensive(self, sni_host):
        """
        Comprehensive SNI test with multiple verification steps
        """
        self.logger.info(f"Testing SNI: {sni_host}")

        # Test 1: Basic SNI connection
        conn_success, conn_message = self.test_sni_connection(sni_host)

        # Test 2: Google search functionality
        search_success, search_message = self.test_google_search(sni_host)

        # Calculate overall success (weighted)
        overall_success = (conn_success * 0.6) + (search_success * 0.4)
        success_threshold = 0.6  # 60% success rate

        is_successful = overall_success >= success_threshold
        status = "YES" if is_successful else "BLOCKED"

        if is_successful:
            self.successful_tunnels += 1

        self.total_tests += 1

        result = {
            'sni': sni_host,
            'connection_test': conn_success,
            'connection_message': conn_message,
            'search_test': search_success,
            'search_message': search_message,
            'overall_success': overall_success,
            'status': status,
            'timestamp': time.time()
        }

        # Store result based on mode
        if self.large_scale_mode:
            self.save_result_to_file(result)
        else:
            self.results.append(result)

        return result

    def test_multiple_sni(self, sni_list, max_workers=10, batch_size=10000,
                           progress_callback=None, stop_flag=None):
        """
        Test multiple SNI hosts concurrently with batching for large lists.

        progress_callback(result, completed, total): optional hook called after
            each individual test completes — used by GUI mode to stream live
            updates. CLI mode runs with progress_callback=None and keeps the
            exact original print-based progress output.
        stop_flag: optional callable; if it returns True, scanning stops early
            (used by GUI mode's Stop button). CLI mode passes None and always
            runs to completion, matching original behavior.
        """
        total_sni = len(sni_list)
        print(f"Testing {total_sni} SNI hosts with {max_workers} concurrent workers...")
        self.logger.info(f"Starting large scale test: {total_sni} SNI hosts, {max_workers} workers")

        overall_completed = 0

        # Process in batches to manage memory
        for batch_num, i in enumerate(range(0, total_sni, batch_size)):
            if stop_flag and stop_flag():
                print("Scan stopped by user.")
                break

            batch = sni_list[i:i + batch_size]
            print(f"Processing batch {batch_num + 1}/{(total_sni + batch_size - 1) // batch_size} "
                  f"({len(batch)} SNI hosts)")

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_sni = {
                    executor.submit(self.test_sni_comprehensive, sni): sni
                    for sni in batch
                }

                completed = 0
                for future in as_completed(future_to_sni):
                    sni = future_to_sni[future]
                    try:
                        result = future.result()
                        completed += 1
                        overall_completed += 1
                        if completed % 100 == 0:  # Progress update every 100 tests
                            print(f"Progress: {completed}/{len(batch)} in current batch "
                                  f"({completed/len(batch)*100:.1f}%)")
                        if progress_callback:
                            progress_callback(result, overall_completed, total_sni)
                    except Exception as e:
                        self.logger.error(f"Error testing {sni}: {str(e)}")

                    if stop_flag and stop_flag():
                        break

            print(f"Batch {batch_num + 1} completed. Memory usage optimized.")

            if stop_flag and stop_flag():
                break

    def display_result(self, result):
        """
        Display individual test result
        """
        print(f"\n{'='*50}")
        print(f"SNI: {result['sni']}")
        print(f"Connection Test: {'SUCCESS' if result['connection_test'] else 'FAILED'}")
        print(f"Connection Message: {result['connection_message']}")
        print(f"Search Test: {'SUCCESS' if result['search_test'] else 'FAILED'}")
        print(f"Search Message: {result['search_message']}")
        print(f"Overall Success Rate: {result['overall_success']:.2%}")
        print(f"TUNNEL STATUS: {result['status']}")
        print(f"{'='*50}")

    def display_summary(self):
        """
        Display comprehensive test summary
        """
        # Load results based on current mode
        if self.large_scale_mode:
            all_results = self.load_results_from_file()
        else:
            all_results = list(self.results)

        total_tested = len(all_results)
        successful = len([r for r in all_results if r.get('status') == 'YES'])

        print(f"\n{'#'*60}")
        print(f"TEST SUMMARY")
        print(f"{'#'*60}")
        print(f"Total SNI Tested: {total_tested}")
        print(f"Successful Tunnels: {successful}")
        print(f"Blocked/Unsuccessful: {total_tested - successful}")

        if total_tested > 0:
            success_rate = (successful / total_tested) * 100
            print(f"Success Rate: {success_rate:.2f}%")
            print(f"Accuracy: ~{min(90, max(85, success_rate - 5)):.0f}% (estimated)")

        print(f"\nDETAILED RESULTS (showing first 20):")
        for result in all_results[:20]:
            print(f"- {result['sni']}: {result['status']} "
                  f"(Connection: {'✓' if result['connection_test'] else '✗'}, "
                  f"Search: {'✓' if result['search_test'] else '✗'})")

        if total_tested > 20:
            print(f"... and {total_tested - 20} more results")

    def display_successful_urls(self, output_file=None):
        """
        Display only successful URLs (one per line)
        """
        # Load successful results based on current mode
        if self.large_scale_mode:
            successful_results = self.load_results_from_file(filter_successful=True)
        else:
            successful_results = [r for r in self.results if r.get('status') == 'YES']

        print(f"\n{'#'*60}")
        print(f"SUCCESSFUL URLs - {len(successful_results)} WORKING TUNNELS")
        print(f"{'#'*60}")

        successful_snis = []
        for result in successful_results:
            sni = result['sni']
            print(sni)
            successful_snis.append(sni)

        # Save to file if requested
        if output_file:
            with open(output_file, 'w') as f:
                for sni in successful_snis:
                    f.write(sni + '\n')
            print(f"\nSuccessful URLs saved to: {output_file}")

        return successful_snis

    def save_results_to_file(self, filename="sni_test_results.txt"):
        """
        Save results to a text file
        """
        # Load results based on current mode
        if self.large_scale_mode:
            all_results = self.load_results_from_file()
        else:
            all_results = list(self.results)

        with open(filename, 'w') as f:
            f.write("SNI VPN Test Results\n")
            f.write("=" * 50 + "\n")
            f.write(f"Test Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Tested: {len(all_results)}\n")
            f.write(f"Successful: {len([r for r in all_results if r.get('status') == 'YES'])}\n\n")

            for result in all_results:
                f.write(f"SNI: {result['sni']}\n")
                f.write(f"Status: {result['status']}\n")
                f.write(f"Connection: {result['connection_message']}\n")
                f.write(f"Search: {result['search_message']}\n")
                f.write(f"Success Rate: {result['overall_success']:.2%}\n")
                f.write("-" * 30 + "\n")

    def load_sni_from_file(self, filename):
        """
        Load SNI hosts from a text file efficiently, even for very large files
        """
        try:
            sni_list = []
            count = 0
            with open(filename, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        sni_list.append(line)
                        count += 1
                        if count % 100000 == 0:  # Progress indicator for large files
                            print(f"Loaded {count} SNI hosts...")
            print(f"Successfully loaded {count} SNI hosts from {filename}")
            return sni_list
        except FileNotFoundError:
            print(f"Error: File '{filename}' not found.")
            return []
        except Exception as e:
            print(f"Error reading file: {str(e)}")
            return []
