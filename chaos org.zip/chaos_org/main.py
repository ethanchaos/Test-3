#!/usr/bin/env python3
"""
chaos_org/main.py
SSL/TLS SNI Scanner — entry point.

Author: EthanChaosS
Organization: Chaos Configurations
Version: 1.1.0
"""

import os
import sys
import socket
import time

VERSION = "1.1.0"

# ── ANSI color helpers ─────────────────────────────────────────────────────────

class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    CYAN    = "\033[96m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    RED     = "\033[91m"
    WHITE   = "\033[97m"
    GRAY    = "\033[90m"
    GRAD1   = "\033[38;5;51m"
    GRAD2   = "\033[38;5;45m"
    GRAD3   = "\033[38;5;39m"
    GRAD4   = "\033[38;5;33m"
    GRAD5   = "\033[38;5;27m"


BANNER_LINES = [
    r"  ██████╗██╗  ██╗ █████╗  ██████╗ ███████╗",
    r" ██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔════╝",
    r" ██║     ███████║███████║██║   ██║███████╗ ",
    r" ██║     ██╔══██║██╔══██║██║   ██║╚════██║",
    r" ╚██████╗██║  ██║██║  ██║╚██████╔╝███████║",
    r"  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝",
]

GRADIENT  = [C.GRAD1, C.GRAD2, C.GRAD3, C.GRAD4, C.GRAD5, C.GRAD5]
TAGLINE   = "       SSL/TLS SNI Scanner  ·  Chaos-Org"
SEPARATOR = "─" * 50


def _supports_color() -> bool:
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(
                ctypes.windll.kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


USE_COLOR = _supports_color()


def color(text: str, *codes: str) -> str:
    return ("".join(codes) + text + C.RESET) if USE_COLOR else text


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def _animate_banner():
    for line, grad in zip(BANNER_LINES, GRADIENT):
        print(color(line, grad, C.BOLD))
        time.sleep(0.04)
    print()
    print(color(TAGLINE, C.CYAN, C.BOLD))
    print(color(SEPARATOR, C.GRAY))
    time.sleep(0.06)


def show_banner():
    clear_screen()
    _animate_banner()
    print()
    print(color("  Author:        ", C.GRAY) + color("EthanChaosS",          C.WHITE, C.BOLD))
    print(color("  Organization:  ", C.GRAY) + color("Chaos Configurations",  C.CYAN))
    print(color("  Version:       ", C.GRAY) + color(f"v{VERSION}",           C.MAGENTA, C.BOLD))
    print()
    print(color(SEPARATOR, C.GRAY))


def show_menu():
    print()
    print(color("  Select launch mode:", C.WHITE, C.BOLD))
    print()
    print(color("  [1]", C.CYAN,    C.BOLD) + color("  GUI Mode", C.WHITE) +
          color("   — web dashboard at http://IP:PORT/dashboard", C.GRAY))
    print(color("  [2]", C.MAGENTA, C.BOLD) + color("  CLI Mode", C.WHITE) +
          color("   — full terminal interface", C.GRAY))
    print()


def info(msg): print(color("  [INFO] ", C.BLUE,   C.BOLD) + msg)
def warn(msg): print(color("  [WARN] ", C.YELLOW, C.BOLD) + msg)
def err(msg):  print(color("  [ERR]  ", C.RED,    C.BOLD) + msg)
def ok(msg):   print(color("  [ OK ] ", C.GREEN,  C.BOLD) + msg)


def main():
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    socket.setdefaulttimeout(30)

    show_banner()
    show_menu()

    choice = input(color("  → ", C.CYAN, C.BOLD)).strip()

    if choice == "1":
        info("Starting GUI mode …")
        from chaos_org.gui_server import run_gui
        run_gui()
    elif choice == "2":
        info("Starting CLI mode …")
        from chaos_org.cli_mode import run_cli
        run_cli()
    else:
        err("Invalid choice. Exiting.")
        sys.exit(1)


if __name__ == "__main__":
    main()
