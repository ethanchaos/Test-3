#!/usr/bin/env python3
"""
pipeline.py
Connects the two SNI-testing tools into one live pipeline:

  Stage 1 (live_check.py)  ->  Stage 2 (sni_core.py SNIVPNTester)

The key behaviour requested: a host does NOT wait for the whole stage-1
batch to finish before moving on. The instant an individual host clears
stage 1, it is handed straight to stage 2's thread pool while stage 1
keeps working through the rest of the list. Both stages' results stream
out live via callbacks.

concurrent_mode=True  (default) -> true pipelining, as described above.
concurrent_mode=False            -> sequential: stage 1 runs to completion
                                     for the whole batch first, THEN stage 2
                                     starts on the hosts that passed. Use
                                     this when you only want one process
                                     hammering the network at a time.
"""

import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor

from . import live_check
from .sni_core import SNIVPNTester

RESULTS_ROOT = "results"
PIPELINE_DIR = os.path.join(RESULTS_ROOT, "pipeline")

FILTERS = ("stage1_only", "confirmed", "stage2_only", "all")


def _ensure_dirs(run_name):
    path = os.path.join(PIPELINE_DIR, run_name)
    os.makedirs(path, exist_ok=True)
    return path


class ReconPipeline:
    def __init__(self):
        self.tester = SNIVPNTester()
        self._stop_requested = False
        self._lock = threading.Lock()
        self.stage1_done = 0
        self.stage2_done = 0
        self.total = 0
        self.records = {}  # host -> combined record

    def stop_flag(self):
        return self._stop_requested

    def request_stop(self):
        self._stop_requested = True

    def _record(self, host):
        with self._lock:
            if host not in self.records:
                self.records[host] = {"host": host, "stage1": None, "stage2": None}
            return self.records[host]

    def _on_stage1_result(self, result, completed, total, stage2_pool, emit):
        host = result["host"]
        rec = self._record(host)
        rec["stage1"] = result
        with self._lock:
            self.stage1_done = completed

        emit({
            "type": "stage1_result",
            "host": host,
            "result": result,
            "completed": completed,
            "total": total,
        })

        if result.get("live") and not self._stop_requested:
            # Fire this host into stage 2 immediately — does not wait for
            # the rest of the stage-1 batch.
            stage2_pool.submit(self._run_stage2_for_host, host, emit)
        else:
            emit({"type": "filtered_out", "host": host, "reason": "failed stage 1"})

    def _run_stage2_for_host(self, host, emit):
        if self._stop_requested:
            return
        result = self.tester.test_sni_comprehensive(host)
        rec = self._record(host)
        rec["stage2"] = result
        with self._lock:
            self.stage2_done += 1

        emit({
            "type": "stage2_result",
            "host": host,
            "result": result,
            "confirmed": result.get("status") == "YES",
            "stage1_total": self.total,
            "stage2_done": self.stage2_done,
        })

    def run(self, hosts, stage1_workers=50, stage2_workers=10, concurrent_mode=True,
            emit=None):
        """
        emit(dict): callback invoked for every live event (thread-safe from
        the caller's perspective — gui_server wraps it to hop back onto the
        asyncio loop).
        """
        emit = emit or (lambda msg: None)
        self._stop_requested = False
        self.stage1_done = 0
        self.stage2_done = 0
        self.records = {}
        self.total = len(hosts)

        emit({"type": "pipeline_started", "total": self.total, "concurrent_mode": concurrent_mode})

        if concurrent_mode:
            # Stage 2 pool stays open the whole time; stage 1 results feed
            # into it as they land.
            with ThreadPoolExecutor(max_workers=stage2_workers) as stage2_pool:
                live_check.run_many(
                    hosts,
                    max_workers=stage1_workers,
                    progress_callback=lambda r, c, t: self._on_stage1_result(r, c, t, stage2_pool, emit),
                    stop_flag=self.stop_flag,
                )
                # stage2_pool context exit waits for any in-flight stage-2 jobs
        else:
            # Sequential: finish ALL of stage 1 first, then start stage 2 —
            # only one of the two tools is ever running at once.
            live_check.run_many(
                hosts,
                max_workers=stage1_workers,
                progress_callback=lambda r, c, t: self._on_stage1_result(
                    r, c, t,
                    _NullPool(),  # swallow stage-2 submissions during stage 1
                    emit,
                ),
                stop_flag=self.stop_flag,
            )
            passed = [h for h, rec in self.records.items() if rec["stage1"] and rec["stage1"].get("live")]
            if passed and not self._stop_requested:
                with ThreadPoolExecutor(max_workers=stage2_workers) as stage2_pool:
                    futures = [stage2_pool.submit(self._run_stage2_for_host, h, emit) for h in passed]
                    for f in futures:
                        if self._stop_requested:
                            break
                        f.result()

        emit({
            "type": "pipeline_finished",
            "stopped": self._stop_requested,
            "stage1_done": self.stage1_done,
            "stage2_done": self.stage2_done,
            "confirmed": len([r for r in self.records.values() if r["stage2"] and r["stage2"].get("status") == "YES"]),
        })

    def filtered_hosts(self, which):
        """which in FILTERS: stage1_only | confirmed | stage2_only | all"""
        out = []
        for host, rec in self.records.items():
            s1 = rec["stage1"]
            s2 = rec["stage2"]
            if which == "stage1_only" and s1 and s1.get("live"):
                out.append(host)
            elif which == "confirmed" and s2 and s2.get("status") == "YES":
                out.append(host)
            elif which == "stage2_only" and s2:
                out.append(host)
            elif which == "all" and (s1 or s2):
                out.append(host)
        return out

    def save_filtered(self, which, run_name, custom_name=None):
        hosts = self.filtered_hosts(which)
        out_dir = _ensure_dirs(run_name)
        fname = custom_name or which
        fname = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", fname)
        if not fname.endswith(".txt"):
            fname += ".txt"
        path = os.path.join(out_dir, fname)
        with open(path, "w") as f:
            for h in hosts:
                f.write(h + "\n")
        return path


class _NullPool:
    """Used in sequential mode so stage-1's callback signature stays the
    same, but nothing actually gets submitted to stage 2 until stage 1 is
    fully done."""
    def submit(self, *a, **kw):
        return None
