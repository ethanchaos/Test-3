#!/usr/bin/env python3
"""
live_check.py
Stage 1 of the recon pipeline — fast HTTPS/HTTP reachability probe.

This is the same test logic as the original 3.py (HA-Tunnel style live
host check on ports 443/80), refactored so it:
  - takes a host list directly instead of hardcoded filenames
  - reports each result the instant it lands via a callback, instead of
    only printing/saving at the end
  - can be chained straight into sni_core's deeper test (see pipeline.py)
"""

import socket
import ssl
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

HA_ELIGIBLE_KEYWORDS = (".gov", ".edu", ".ac.za", ".org", ".netlify.app", ".za", ".int")


def is_ha_eligible(host: str) -> bool:
    return any(kw in host for kw in HA_ELIGIBLE_KEYWORDS)


def test_https(host, timeout=5):
    try:
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        conn = socket.create_connection((host, 443), timeout=timeout)
        start = time.time()
        sock = context.wrap_socket(conn, server_hostname=host)
        sock.getpeercert()
        sock.close()
        return True, round(time.time() - start, 2), "HTTPS"
    except Exception:
        return False, None, "HTTPS"


def test_http(host, timeout=5):
    try:
        start = time.time()
        conn = socket.create_connection((host, 80), timeout=timeout)
        conn.send(b"HEAD / HTTP/1.1\r\nHost: " + host.encode() + b"\r\n\r\n")
        response = conn.recv(1024)
        conn.close()
        if response.startswith(b"HTTP/"):
            return True, round(time.time() - start, 2), "HTTP"
        return False, None, "HTTP"
    except Exception:
        return False, None, "HTTP"


def test_host(host, timeout=5):
    """Try HTTPS first, fall back to HTTP. Returns a result dict."""
    ok, duration, proto = test_https(host, timeout)
    if not ok:
        ok, duration, proto = test_http(host, timeout)
        proto = proto if ok else None

    return {
        "host": host,
        "live": ok,
        "protocol": proto,
        "duration": duration,
        "ha_eligible": is_ha_eligible(host) if ok else False,
    }


def run_many(hosts, max_workers=50, timeout=5, progress_callback=None, stop_flag=None):
    """
    Test many hosts concurrently. Calls progress_callback(result, completed,
    total) the moment each individual host finishes — this is what lets
    pipeline.py forward a passing host into stage 2 immediately, without
    waiting for the rest of the batch.
    """
    total = len(hosts)
    completed = 0
    results = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(test_host, h, timeout): h for h in hosts}
        for future in as_completed(futures):
            if stop_flag and stop_flag():
                break
            host = futures[future]
            try:
                result = future.result()
            except Exception as e:
                result = {"host": host, "live": False, "protocol": None, "duration": None,
                          "ha_eligible": False, "error": str(e)}
            completed += 1
            results.append(result)
            if progress_callback:
                progress_callback(result, completed, total)

    return results


def save_live_hosts(live_results, filename="live_hosts.txt"):
    with open(filename, "w") as f:
        for r in live_results:
            if r.get("live"):
                f.write(f"{r['host']} | {r['protocol']} | {r['duration']}s\n")
    return filename
