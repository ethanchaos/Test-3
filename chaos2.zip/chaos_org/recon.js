/* ════════════════════════════════════════════════════════════
   TECH WARLORDS — Subdomain Finder + Live Pipeline
   Base subdomain enumeration is exactly what you built: browser-
   side, hits crt.sh / HackerTarget / AlienVault OTX / ThreatMiner
   in parallel per domain, no backend required — it "works
   independently" as asked. On top of that this file adds:
     - multi-domain looping (single / paste / file), sequential or
       several domains at once
     - an optional save-to-backend call (only used if gui_server.py
       is reachable) so results land in results/subdomains/ alongside
       the Python-side scans, instead of only a browser download
     - a Live Pipeline section that talks to gui_server.py's
       WebSocket bridge (chaos_org/live_check.py -> sni_core.py),
       since SNI/SSL testing needs raw sockets a browser can't open
   ════════════════════════════════════════════════════════════ */

(function () {
    const form = document.getElementById('sdfForm');
    const domainInput = document.getElementById('domainInput');
    const domainsPaste = document.getElementById('domainsPaste');
    const domainsFilePicker = document.getElementById('domainsFilePicker');
    const domainsFilePath = document.getElementById('domainsFilePath');
    const pasteCount = document.getElementById('pasteCount');
    const scanBtn = document.getElementById('scanBtn');
    const scanBtnLabel = document.getElementById('scanBtnLabel');
    const hint = document.getElementById('sdfHint');

    const foundCountEl = document.getElementById('foundCount');
    const sourcesCountEl = document.getElementById('sourcesCount');
    const elapsedTimeEl = document.getElementById('elapsedTime');

    const sourceListEl = document.getElementById('sourceList');
    const terminalEl = document.getElementById('terminal');
    const resultCountBadge = document.getElementById('resultCountBadge');

    const domainProgressHead = document.getElementById('domainProgressHead');
    const domainProgressList = document.getElementById('domainProgressList');
    const domainProgressBadge = document.getElementById('domainProgressBadge');

    const copyBtn = document.getElementById('copyBtn');
    const saveBtn = document.getElementById('saveBtn');
    const clearBtn = document.getElementById('clearBtn');
    const sendToPipelineBtn = document.getElementById('sendToPipelineBtn');

    const SOURCE_TIMEOUT_MS = 12000;

    /* ── Sources (unchanged from your original) ─────────────────── */
    const SOURCES = [
        {
            name: 'crt.sh (Certificate Transparency)',
            async run(domain, signal) {
                const res = await fetch(`https://crt.sh/?q=%25.${encodeURIComponent(domain)}&output=json`, { signal });
                if (!res.ok) throw new Error('bad status');
                const data = await res.json();
                const out = [];
                data.forEach(entry => {
                    (entry.name_value || '').split('\n').forEach(h => out.push(h));
                    if (entry.common_name) out.push(entry.common_name);
                });
                return out;
            }
        },
        {
            name: 'HackerTarget (Host Search)',
            async run(domain, signal) {
                const res = await fetch(`https://api.hackertarget.com/hostsearch/?q=${encodeURIComponent(domain)}`, { signal });
                const text = await res.text();
                if (!res.ok || /error|API count exceeded/i.test(text)) throw new Error('blocked or rate-limited');
                return text.split('\n').map(line => line.split(',')[0]);
            }
        },
        {
            name: 'AlienVault OTX (Passive DNS)',
            async run(domain, signal) {
                const res = await fetch(`https://otx.alienvault.com/api/v1/indicators/domain/${encodeURIComponent(domain)}/passive_dns`, { signal });
                if (!res.ok) throw new Error('bad status');
                const data = await res.json();
                return (data.passive_dns || []).map(e => e.hostname);
            }
        },
        {
            name: 'ThreatMiner',
            async run(domain, signal) {
                const res = await fetch(`https://api.threatminer.org/v2/domain.php?q=${encodeURIComponent(domain)}&rt=5`, { signal });
                if (!res.ok) throw new Error('bad status');
                const data = await res.json();
                if (String(data.status_code) !== '200') throw new Error('no data');
                return data.results || [];
            }
        }
    ];

    /* ── State ───────────────────────────────────────────────── */
    let found = new Set();               // aggregate across all domains in this run
    let foundByDomain = {};              // domain -> Set
    let scanning = false;
    let elapsedTimer = null;
    let scanStart = 0;
    let currentDomains = [];
    let loadedFileDomains = [];

    /* ── Helpers (unchanged) ─────────────────────────────────── */
    function sanitizeDomain(raw) {
        let d = raw.trim().toLowerCase();
        d = d.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
        d = d.replace(/:.*/, '');
        d = d.replace(/^\*\./, '').replace(/\.$/, '');
        return d;
    }

    function isValidDomain(d) {
        return /^(?!-)[a-z0-9-]{1,63}(?<!-)(\.[a-z0-9-]{1,63})+$/.test(d);
    }

    function cleanHostname(raw, domain) {
        if (!raw) return null;
        let h = raw.trim().toLowerCase().replace(/^\*\./, '').replace(/\.$/, '');
        if (!h || h.includes(' ') || h.includes('@')) return null;
        if (!/^[a-z0-9.-]+$/.test(h)) return null;
        if (h !== domain && !h.endsWith('.' + domain)) return null;
        return h;
    }

    function parseDomainList(text) {
        const out = []; const seen = new Set();
        text.split('\n').forEach(line => {
            const d = sanitizeDomain(line);
            if (d && isValidDomain(d) && !seen.has(d)) { seen.add(d); out.push(d); }
        });
        return out;
    }

    function setStat(el, text, pulse) {
        el.textContent = text;
        if (pulse) {
            el.classList.remove('sdf-pulse');
            void el.offsetWidth;
            el.classList.add('sdf-pulse');
        }
    }

    function updateElapsed() {
        const secs = (performance.now() - scanStart) / 1000;
        elapsedTimeEl.textContent = secs.toFixed(1) + 's';
    }

    function addResultLine(host, domain) {
        const empty = document.getElementById('terminalEmpty');
        if (empty) empty.remove();
        const row = document.createElement('div');
        row.className = 'sdf-line';
        row.innerHTML = `<i class="fas fa-caret-right"></i><span></span>`;
        row.querySelector('span').textContent = currentDomains.length > 1 ? `${host}  ·  ${domain}` : host;
        terminalEl.appendChild(row);
        terminalEl.scrollTop = terminalEl.scrollHeight;
    }

    function renderSourceRows() {
        sourceListEl.innerHTML = SOURCES.map((s, i) => `
            <div class="sdf-source-row sdf-queued" id="src-${i}">
                <span class="sdf-source-dot"></span>
                <span class="sdf-source-name">${s.name}</span>
                <span class="sdf-source-status">queued</span>
            </div>`).join('');
    }

    function setSourceState(i, state, statusText) {
        const row = document.getElementById(`src-${i}`);
        if (!row) return;
        row.className = `sdf-source-row sdf-${state}`;
        row.querySelector('.sdf-source-status').textContent = statusText;
    }

    function renderDomainProgress() {
        if (currentDomains.length <= 1) { domainProgressHead.style.display = 'none'; domainProgressList.innerHTML = ''; return; }
        domainProgressHead.style.display = '';
        const done = currentDomains.filter(d => foundByDomain[d] && foundByDomain[d].__done).length;
        domainProgressBadge.textContent = `${done}/${currentDomains.length}`;
        domainProgressList.innerHTML = currentDomains.map(d => {
            const set = foundByDomain[d];
            const doneD = set && set.__done;
            const count = set ? set.size : 0;
            const cls = doneD ? (count > 0 ? 'sdf-ok' : 'sdf-empty') : 'sdf-active';
            const status = doneD ? `${count} found` : 'scanning…';
            return `<div class="sdf-source-row ${cls}"><span class="sdf-source-dot"></span><span class="sdf-source-name">${d}</span><span class="sdf-source-status">${status}</span></div>`;
        }).join('');
    }

    function refreshActionButtons() {
        const has = found.size > 0;
        copyBtn.disabled = !has;
        saveBtn.disabled = !has;
        clearBtn.disabled = !has && !scanning;
        sendToPipelineBtn.disabled = !has;
    }

    /* ── Scan a single domain against all sources ───────────── */
    async function scanOneDomain(domain) {
        const domainSet = new Set();
        foundByDomain[domain] = domainSet;

        let doneCount = 0;
        const tasks = SOURCES.map((source, i) => {
            if (currentDomains.length === 1) setSourceState(i, 'active', 'querying…');
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), SOURCE_TIMEOUT_MS);

            return source.run(domain, controller.signal)
                .then(rawList => {
                    let added = 0;
                    (rawList || []).forEach(raw => {
                        const clean = cleanHostname(raw, domain);
                        if (clean && !domainSet.has(clean)) {
                            domainSet.add(clean);
                            if (!found.has(clean)) {
                                found.add(clean);
                                added++;
                                addResultLine(clean, domain);
                                setStat(foundCountEl, String(found.size), true);
                                resultCountBadge.textContent = String(found.size);
                                refreshActionButtons();
                            }
                        }
                    });
                    if (currentDomains.length === 1) setSourceState(i, added > 0 ? 'ok' : 'empty', added > 0 ? `+${added} found` : 'no results');
                })
                .catch(() => {
                    if (currentDomains.length === 1) setSourceState(i, 'fail', 'unreachable');
                })
                .finally(() => {
                    clearTimeout(timeout);
                    doneCount++;
                    if (currentDomains.length === 1) setStat(sourcesCountEl, `${doneCount}/${SOURCES.length}`);
                });
        });

        await Promise.allSettled(tasks);
        domainSet.__done = true;
        renderDomainProgress();

        if (backendConnected) {
            saveDomainResultsToBackend(domain, [...domainSet]);
        }
        return domainSet;
    }

    /* ── Run scan across 1..N domains, sequential or N-at-once ── */
    async function runScan(domains, opts) {
        currentDomains = domains;
        found = new Set();
        foundByDomain = {};
        scanning = true;

        terminalEl.innerHTML = '';
        setStat(foundCountEl, '0');
        setStat(sourcesCountEl, domains.length > 1 ? `${domains.length} domains` : `0/${SOURCES.length}`);
        elapsedTimeEl.textContent = '0.0s';
        renderSourceRows();
        if (domains.length > 1) sourceListEl.parentElement.style.opacity = '.6';
        else sourceListEl.parentElement.style.opacity = '1';
        renderDomainProgress();
        refreshActionButtons();

        scanBtn.disabled = true;
        scanBtn.classList.add('sdf-scanning');
        scanBtnLabel.textContent = 'Scanning…';
        hint.classList.remove('sdf-error');
        hint.textContent = domains.length > 1
            ? `Scanning ${domains.length} domains — ${opts.sequential ? 'one at a time' : `up to ${opts.concurrent} at once`}…`
            : `Querying ${SOURCES.length} passive sources for ${domains[0]}…`;

        scanStart = performance.now();
        elapsedTimer = setInterval(updateElapsed, 100);

        const concurrency = opts.sequential ? 1 : Math.max(1, opts.concurrent);
        let idx = 0;
        async function worker() {
            while (idx < domains.length) {
                const d = domains[idx++];
                await scanOneDomain(d);
            }
        }
        await Promise.all(Array.from({ length: Math.min(concurrency, domains.length) }, worker));

        clearInterval(elapsedTimer);
        updateElapsed();
        scanning = false;
        scanBtn.disabled = false;
        scanBtn.classList.remove('sdf-scanning');
        scanBtnLabel.textContent = 'Start Scan';
        refreshActionButtons();

        if (found.size === 0) {
            hint.classList.add('sdf-error');
            hint.textContent = `No subdomains surfaced — some sources may be rate-limited or unreachable from a browser. Try again shortly.`;
            if (!terminalEl.querySelector('.sdf-line')) {
                terminalEl.innerHTML = `<div class="tw-empty" id="terminalEmpty"><i class="fas fa-satellite-dish"></i>No subdomains found</div>`;
            }
        } else {
            hint.textContent = `Done — ${found.size} unique subdomain${found.size === 1 ? '' : 's'} across ${domains.length} domain${domains.length === 1 ? '' : 's'} in ${elapsedTimeEl.textContent}.`;
        }
    }

    /* ── Input mode switching ───────────────────────────────── */
    window.switchSDMode = function (m) {
        ['single', 'paste', 'file'].forEach(k => {
            document.getElementById('sdInput' + k[0].toUpperCase() + k.slice(1)).style.display = k === m ? '' : 'none';
            document.getElementById('sdMode' + k[0].toUpperCase() + k.slice(1)).classList.toggle('active', k === m);
        });
        document.getElementById('sdSequentialRow').style.display = m === 'single' ? 'none' : 'flex';
    };

    if (domainsPaste) {
        domainsPaste.addEventListener('input', function () {
            pasteCount.textContent = parseDomainList(this.value).length + ' domains detected';
        });
    }
    if (domainsFilePicker) {
        domainsFilePicker.addEventListener('change', (e) => {
            const file = e.target.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = ev => {
                loadedFileDomains = parseDomainList(ev.target.result);
                domainsFilePath.value = `${file.name} (${loadedFileDomains.length})`;
            };
            reader.readAsText(file);
        });
    }

    function collectDomains() {
        if (document.getElementById('sdModeSingle').classList.contains('active')) {
            const d = sanitizeDomain(domainInput.value);
            return isValidDomain(d) ? [d] : [];
        }
        if (document.getElementById('sdModeFile').classList.contains('active')) return loadedFileDomains;
        return parseDomainList(domainsPaste.value);
    }

    window.toggleSwitch = function (id) { document.getElementById(id).classList.toggle('on'); };
    function isOn(id) { return document.getElementById(id).classList.contains('on'); }
    document.getElementById('sdSequentialRow').addEventListener('click', () => toggleSwitch('sdSequential'));

    /* ── Events ──────────────────────────────────────────────── */
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (scanning) return;
        const domains = collectDomains();
        if (!domains.length) {
            hint.classList.add('sdf-error');
            hint.textContent = 'Enter at least one valid domain, e.g. example.com';
            return;
        }
        if (document.getElementById('sdModeSingle').classList.contains('active')) domainInput.value = domains[0];
        runScan(domains, {
            sequential: isOn('sdSequential'),
            concurrent: parseInt(document.getElementById('sdConcurrent').value, 10) || 3,
        });
    });

    copyBtn.addEventListener('click', async () => {
        const text = [...found].sort().join('\n');
        try { await navigator.clipboard.writeText(text); }
        catch (e) { /* clipboard unavailable — Save .txt still works */ }
    });

    saveBtn.addEventListener('click', () => {
        const text = [...found].sort().join('\n') + '\n';
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const customName = document.getElementById('sdCustomName').value.trim();
        a.download = (customName || (currentDomains[0] || 'subdomains') + '-subdomains') + '.txt';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    });

    clearBtn.addEventListener('click', () => {
        found = new Set();
        foundByDomain = {};
        currentDomains = [];
        terminalEl.innerHTML = `<div class="tw-empty" id="terminalEmpty"><i class="fas fa-satellite-dish"></i>Run a scan to see subdomains stream in here</div>`;
        resultCountBadge.textContent = '0';
        setStat(foundCountEl, '0');
        setStat(sourcesCountEl, `0/${SOURCES.length}`);
        elapsedTimeEl.textContent = '0.0s';
        sourceListEl.innerHTML = '';
        domainProgressList.innerHTML = '';
        domainProgressHead.style.display = 'none';
        hint.classList.remove('sdf-error');
        hint.textContent = 'Enter a domain you own or are authorized to test.';
        refreshActionButtons();
    });

    /* Init */
    setStat(sourcesCountEl, `0/${SOURCES.length}`);
    refreshActionButtons();

    /* ═══════════════════════════════════════════════════════════
       Matrix rain (self-contained — techwarlords-core.js not
       part of this package)
       ═══════════════════════════════════════════════════════════ */
    (function () {
        const canvas = document.getElementById('matrixCanvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        let w, h, cols, drops;
        const chars = '01アカサタナハマヤラワ';
        function resize() {
            w = canvas.width = window.innerWidth;
            h = canvas.height = window.innerHeight;
            cols = Math.floor(w / 16);
            drops = new Array(cols).fill(0);
        }
        window.addEventListener('resize', resize);
        resize();
        function draw() {
            ctx.fillStyle = 'rgba(3,4,5,0.08)';
            ctx.fillRect(0, 0, w, h);
            ctx.fillStyle = '#ff1f3d';
            ctx.font = '14px monospace';
            for (let i = 0; i < drops.length; i++) {
                ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * 16, drops[i] * 16);
                if (drops[i] * 16 > h && Math.random() > 0.975) drops[i] = 0;
                drops[i]++;
            }
        }
        setInterval(draw, 60);
    })();

    /* ═══════════════════════════════════════════════════════════
       Backend bridge (gui_server.py) — optional. The subdomain
       finder above works with zero backend, exactly as you built
       it. If gui_server.py happens to be running (same machine,
       port 8001), we also mirror results into results/subdomains/
       and light up the Live Pipeline section.
       ═══════════════════════════════════════════════════════════ */
    const WS_PORT = 8001;
    let ws = null;
    let backendConnected = false;
    let pending = null;

    function wsUrl() { return `ws://${window.location.hostname || '127.0.0.1'}:${WS_PORT}`; }

    function connectWS() {
        if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
        try { ws = new WebSocket(wsUrl()); } catch (e) { return; }
        ws.onopen = () => {
            backendConnected = true;
            setBackendStatus(true);
            if (pending) { ws.send(JSON.stringify(pending)); pending = null; }
        };
        ws.onclose = () => { backendConnected = false; setBackendStatus(false); setTimeout(connectWS, 3000); };
        ws.onerror = () => { backendConnected = false; setBackendStatus(false); };
        ws.onmessage = (event) => {
            let msg; try { msg = JSON.parse(event.data); } catch (e) { return; }
            handleServerMessage(msg);
        };
    }
    function setBackendStatus(connected) {
        const dot = document.getElementById('backendDot');
        const label = document.getElementById('backendLabel');
        if (!dot || !label) return;
        dot.classList.toggle('on', connected);
        label.textContent = connected
            ? 'Backend connected — results also saving to results/subdomains/'
            : 'Backend offline — subdomain finder still works standalone';
    }
    function sendWS(payload) {
        if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
        else { pending = payload; connectWS(); }
    }
    connectWS();

    function saveDomainResultsToBackend(domain, hosts) {
        sendWS({ action: 'save_client_subdomains', domain, hosts,
                 custom_name: document.getElementById('sdCustomName').value.trim() || null });
    }

    window.sendFoundToPipeline = function () {
        pl.loadedFromResults = [...found];
        window.switchView('pipeline');
        ['file','single','results','paste'].forEach(k => {
            document.getElementById('plInput' + k[0].toUpperCase() + k.slice(1)).style.display = 'none';
            document.getElementById('plMode' + k[0].toUpperCase() + k.slice(1)).classList.remove('active');
        });
        document.getElementById('plPasteHosts').value = [...found].join('\n');
        document.getElementById('plInputPaste').style.display = '';
        document.getElementById('plModePaste').classList.add('active');
    };

    /* ── Sub-nav ─────────────────────────────────────────────── */
    window.switchView = function (which) {
        document.getElementById('viewSubdomain').style.display = which === 'subdomain' ? '' : 'none';
        document.getElementById('viewPipeline').style.display  = which === 'pipeline'  ? '' : 'none';
        document.getElementById('navSubdomain').classList.toggle('active', which === 'subdomain');
        document.getElementById('navPipeline').classList.toggle('active', which === 'pipeline');
        if (which === 'pipeline') sendWS({ action: 'list_results' });
    };

    function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function parseHosts(text) { return text.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#')); }

    function handleServerMessage(msg) {
        switch (msg.type) {
            case 'results_list': populateResultsSelect(msg.results); break;
            case 'result_loaded':
                pl.loadedFromResults = msg.hosts;
                plLine('s1', 'info', `Loaded ${msg.hosts.length} hosts from ${esc(msg.path)}`);
                break;
            case 'pipeline_started':
                pl.total = msg.total; pl.s1done = 0; pl.live = 0; pl.confirmed = 0; pl.records = {};
                updatePLStats();
                break;
            case 'stage1_result': {
                const r = msg.result;
                pl.s1done = msg.completed;
                if (r.live) pl.live++;
                plRecord(r.host).stage1 = r;
                plLine('s1', r.live ? 'ok' : 'fail', `${esc(r.host)} — ${r.live ? r.protocol + ' ' + r.duration + 's' : 'dead'}`);
                updatePLStats(); renderPLResults();
                break;
            }
            case 'stage2_result': {
                const r = msg.result;
                if (msg.confirmed) pl.confirmed++;
                plRecord(msg.host).stage2 = r;
                plLine('s2', msg.confirmed ? 'ok' : 'fail', `${esc(msg.host)} — ${msg.confirmed ? 'CONFIRMED' : 'blocked'}`);
                updatePLStats(); renderPLResults();
                break;
            }
            case 'pipeline_finished':
                plFinish();
                document.getElementById('plResultsHead').style.display = '';
                document.getElementById('plFilterRow').style.display = 'flex';
                document.getElementById('plResultsList').style.display = '';
                document.getElementById('plSaveRow').style.display = 'flex';
                break;
            case 'saved':
                plLine('s2', 'info', `Saved to ${esc(msg.path)}`);
                break;
            case 'error':
                plLine('s1', 'fail', esc(msg.message || 'error'));
                plFinish();
                break;
        }
    }

    /* ═══════════════════════════════════════════════════════════
       Live Pipeline (stage1 live-check -> stage2 SNI/SSL test)
       ═══════════════════════════════════════════════════════════ */
    const pl = { total: 0, s1done: 0, live: 0, confirmed: 0, records: {}, filter: 'all', loadedFromResults: [] };

    window.switchPLMode = function (m) {
        ['file','single','results','paste'].forEach(k => {
            document.getElementById('plInput' + k[0].toUpperCase() + k.slice(1)).style.display = k === m ? '' : 'none';
            document.getElementById('plMode' + k[0].toUpperCase() + k.slice(1)).classList.toggle('active', k === m);
        });
        if (m === 'results') sendWS({ action: 'list_results' });
    };
    document.getElementById('plConcurrentRow').addEventListener('click', () => toggleSwitch('plConcurrent'));

    const plFilePicker = document.getElementById('plFilePicker');
    let plLoadedFileHosts = [];
    if (plFilePicker) {
        plFilePicker.addEventListener('change', (e) => {
            const file = e.target.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = ev => {
                plLoadedFileHosts = parseHosts(ev.target.result);
                document.getElementById('plFilePath').value = `${file.name} (${plLoadedFileHosts.length})`;
            };
            reader.readAsText(file);
        });
    }

    function populateResultsSelect(results) {
        const sel = document.getElementById('plResultsSelect');
        if (!sel) return;
        const opts = ['<option value="">— choose a saved results file —</option>'];
        (results.subdomains || []).forEach(f => opts.push(`<option value="subdomains|${esc(f)}">subdomains/${esc(f)}</option>`));
        (results.pipeline || []).forEach(f => opts.push(`<option value="pipeline|${esc(f)}">pipeline/${esc(f)}</option>`));
        sel.innerHTML = opts.join('');
    }
    window.loadPLResultSelection = function () {
        const val = document.getElementById('plResultsSelect').value; if (!val) return;
        const [kind, path] = val.split('|');
        sendWS({ action: 'load_result', kind, path });
    };

    function collectPLHosts() {
        if (document.getElementById('plModeSingle').classList.contains('active')) {
            const v = document.getElementById('plSingleHost').value.trim();
            return v ? [v] : [];
        }
        if (document.getElementById('plModeResults').classList.contains('active')) return pl.loadedFromResults;
        if (document.getElementById('plModePaste').classList.contains('active')) return parseHosts(document.getElementById('plPasteHosts').value);
        return plLoadedFileHosts;
    }

    window.startPipelineScan = function () {
        const hosts = collectPLHosts();
        if (!hosts.length) { plLine('s1', 'fail', 'No hosts to test.'); return; }
        pl.records = {}; pl.s1done = 0; pl.live = 0; pl.confirmed = 0;
        document.getElementById('plFeedS1').innerHTML = '';
        document.getElementById('plFeedS2').innerHTML = '';
        document.getElementById('plResultsHead').style.display = 'none';
        document.getElementById('plFilterRow').style.display = 'none';
        document.getElementById('plResultsList').style.display = 'none';
        document.getElementById('plSaveRow').style.display = 'none';
        updatePLStats();
        const btn = document.getElementById('btnPlRun');
        btn.classList.add('sdf-scanning'); btn.disabled = true;
        plLine('s1', 'info', `Starting — ${hosts.length} host(s)`);
        sendWS({
            action: 'start_pipeline_scan',
            hosts,
            stage1_workers: parseInt(document.getElementById('plStage1Workers').value, 10) || 50,
            stage2_workers: parseInt(document.getElementById('plStage2Workers').value, 10) || 10,
            concurrent_mode: isOn('plConcurrent'),
        });
    };
    window.stopPipelineScan = function () { sendWS({ action: 'stop_pipeline_scan' }); plLine('s1', 'info', 'Stop requested...'); };
    function plFinish() { const btn = document.getElementById('btnPlRun'); btn.classList.remove('sdf-scanning'); btn.disabled = false; }
    function plRecord(host) { if (!pl.records[host]) pl.records[host] = { host, stage1: null, stage2: null }; return pl.records[host]; }
    function plLine(which, type, text) {
        const term = document.getElementById('plFeed' + which[0].toUpperCase() + which.slice(1));
        const icon = type === 'ok' ? 'fa-check' : type === 'fail' ? 'fa-xmark' : 'fa-circle-info';
        const row = document.createElement('div');
        row.className = 'sdf-line';
        row.innerHTML = `<i class="fas ${icon}"></i><span>${text}</span>`;
        term.appendChild(row);
        term.scrollTop = term.scrollHeight;
        while (term.children.length > 150) term.removeChild(term.firstChild);
    }
    function updatePLStats() {
        document.getElementById('plStatS1').textContent = pl.s1done;
        document.getElementById('plStatLive').textContent = pl.live;
        document.getElementById('plStatConfirmed').textContent = pl.confirmed;
    }
    window.setPLFilter = function (f) {
        pl.filter = f;
        document.querySelectorAll('#plFilterRow .tw-chip').forEach(c => c.classList.toggle('active', c.dataset.f === f));
        renderPLResults();
    };
    function renderPLResults() {
        const list = document.getElementById('plResultsList');
        list.style.display = '';
        const rows = Object.values(pl.records).filter(rec => {
            const s1 = rec.stage1, s2 = rec.stage2;
            if (pl.filter === 'stage1_only') return s1 && s1.live;
            if (pl.filter === 'confirmed')   return s2 && s2.status === 'YES';
            if (pl.filter === 'stage2_only') return !!s2;
            return s1 || s2;
        });
        list.innerHTML = rows.slice(0, 300).map(rec => {
            const s2 = rec.stage2;
            let status = 'pending';
            if (s2) status = s2.status === 'YES' ? 'confirmed' : 'blocked';
            else if (rec.stage1 && rec.stage1.live) status = 'live (stage 1 only)';
            return `<div class="sdf-line"><i class="fas fa-circle"></i><span>${esc(rec.host)} — ${status}</span></div>`;
        }).join('') || '<div class="tw-empty">No hosts match this filter yet.</div>';
    }
    window.savePipelineResults = function () {
        const name = document.getElementById('plSaveName').value.trim() || null;
        sendWS({ action: 'save_pipeline_results', filter: pl.filter, run_name: 'run_' + Date.now(), custom_name: name });
    };
})();
