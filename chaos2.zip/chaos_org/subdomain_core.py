#!/usr/bin/env python3
"""
subdomain_core.py
Multi-target subdomain enumeration engine — wraps sublist3r.py so it can
enumerate MANY domains at once instead of just one, and streams results
live instead of only printing/writing at the end.

sublist3r.py itself is left untouched (its `main()` is the original,
unmodified enumeration logic) — this module just calls it once per domain,
in parallel, across a thread pool, and gives each call:
  - its own subdomains_<domain>.txt file under results/subdomains/
  - a live progress_callback so the GUI can stream hostnames as they land
"""

import os
import re
import time
import random
import string
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import sublist3r

RESULTS_ROOT = "results"
SUBDOMAIN_DIR = os.path.join(RESULTS_ROOT, "subdomains")

_DOMAIN_RE = re.compile(r"^[a-zA-Z0-9](?:[a-zA-Z0-9\-\.]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$")


def _ensure_dirs():
    os.makedirs(SUBDOMAIN_DIR, exist_ok=True)


def _clean_domain(raw: str) -> str:
    d = raw.strip().lower()
    d = re.sub(r"^https?://", "", d)
    d = d.split("/")[0]
    return d


def parse_domains_blob(text: str):
    """Turn pasted text / uploaded file content into a clean domain list."""
    out = []
    seen = set()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        d = _clean_domain(line)
        if d and d not in seen and _DOMAIN_RE.match(d):
            seen.add(d)
            out.append(d)
    return out


def random_suffix(n=6):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def result_path_for(domain: str, custom_name: str = None) -> str:
    _ensure_dirs()
    if custom_name:
        safe = re.sub(r"[^a-zA-Z0-9_\-\.]", "_", custom_name)
        if not safe.endswith(".txt"):
            safe += ".txt"
        return os.path.join(SUBDOMAIN_DIR, safe)
    return os.path.join(SUBDOMAIN_DIR, f"{domain}_{random_suffix()}.txt")


class SubdomainEnumerator:
    """
    Runs sublist3r's engines against N domains at once.

    run_many(domains, ...) fires one worker per domain (bounded by
    max_concurrent_domains). Each worker calls the ORIGINAL sublist3r.main()
    for that single domain, then reports every found subdomain back through
    progress_callback the moment that domain's scan finishes (sublist3r
    itself only returns a final list — it doesn't stream per-hostname — so
    "live" here means "as each domain completes", not sub-hostname level).
    """

    def __init__(self):
        self._stop_requested = False
        self._lock = threading.Lock()

    def stop_flag(self):
        return self._stop_requested

    def request_stop(self):
        self._stop_requested = True

    def _scan_one(self, domain, threads, enable_bruteforce, engines, custom_name):
        save_path = result_path_for(domain, custom_name if len(custom_name or "") else None)
        try:
            subs = sublist3r.main(
                domain,
                threads,
                None,          # we write the file ourselves (sublist3r's own writer is fine too)
                None,          # ports
                True,          # silent — we don't want sublist3r's own prints flooding the GUI log
                False,         # verbose
                enable_bruteforce,
                engines,
            )
        except Exception as e:
            return {"domain": domain, "error": str(e), "subdomains": [], "file": None}

        subs = list(subs) if subs else []
        with open(save_path, "w") as f:
            for s in subs:
                f.write(s + "\n")

        return {"domain": domain, "error": None, "subdomains": subs, "file": save_path}

    def run_many(self, domains, threads=20, enable_bruteforce=False, engines=None,
                 max_concurrent_domains=3, progress_callback=None, custom_name=None,
                 sequential=False):
        """
        domains: list[str]
        sequential=True  -> one domain at a time (max_concurrent_domains forced to 1)
        sequential=False -> up to max_concurrent_domains run together
        """
        self._stop_requested = False
        workers = 1 if sequential else max(1, max_concurrent_domains)
        total = len(domains)
        completed = 0
        all_results = []

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {
                executor.submit(self._scan_one, d, threads, enable_bruteforce, engines, custom_name): d
                for d in domains
            }
            for future in as_completed(futures):
                domain = futures[future]
                if self._stop_requested:
                    break
                try:
                    result = future.result()
                except Exception as e:
                    result = {"domain": domain, "error": str(e), "subdomains": [], "file": None}

                completed += 1
                all_results.append(result)
                if progress_callback:
                    progress_callback(result, completed, total)

        return all_results
