# Chaos-Org — Recon Update (Subdomain Finder + Live Pipeline)

## `recon.html` — now built from your actual file

The previous version of this update rebuilt the TECH WARLORDS look from
scratch. This version uses your real `subdomain-finder.html` /
`subdomain-finder.css` / `subdomain-finder.js` directly (renamed
`recon.html/css/js`), edited in place:

- **Preloader removed** (`tw-loader` block) — no loading screen.
- **Nav icon removed** (the `logo-icon.png` mark) — logo is text-only now.
- Your original passive-source subdomain logic (crt.sh / HackerTarget /
  AlienVault OTX / ThreatMiner) is untouched — it still runs entirely in
  the browser, no backend required, exactly as you built it.
- Added on top: **Single Site / Paste Multiple / Upload File** target
  modes, a "domains at once" concurrency setting + sequential toggle, and
  a **Send Results to Pipeline** button.
- Added a **Live Pipeline** section (needs the Python backend running) —
  same stage1→stage2 chaining as before, reachable via the new sub-nav at
  the top of the page.
- If `gui_server.py` happens to be running when you open this page, a
  small status dot at the top shows "Backend connected" and every
  domain's results also get mirrored into `results/subdomains/`
  automatically (new WS action `save_client_subdomains`) — so they show
  up in "From Results" on the Pipeline side too. If the backend isn't
  running, the finder still works fully standalone — nothing about it
  depends on Python.
- `techwarlords.css` / `techwarlords-core.js` / `ads.js` weren't part of
  your upload, so `recon.css` now defines the `--tw-*` tokens and base
  layout classes itself (same red/black look, just self-contained), and
  `recon.js` includes its own small matrix-rain script in place of
  `techwarlords-core.js`'s.

**What I trimmed, since none of it applies to a standalone local tool:**
the `tw-ad-slot` div (no `ads.js` here to fill it), the "← Tools" back
link (`tools.html` isn't part of this package), and the bottom site nav
(links to `index.html`/`apps.html`/etc. that don't exist here). If you
want this page living inside the actual TECH WARLORDS site instead of
standalone, say so and I'll restore those and point them at the real
site pages.

## What's new (backend)

**3 backend scripts, as requested:**

1. `chaos_org/subdomain_core.py` — wraps the original `sublist3r.py` (included,
   lightly patched — see below) so it can enumerate **many domains at once**
   instead of just one. Runs domains in parallel (configurable how many at
   once) or one-at-a-time. Each domain's results are saved to their own file
   under `results/subdomains/`.
2. `chaos_org/live_check.py` — Stage 1 of the pipeline. This is your `3.py`
   (HA-Tunnel-style HTTPS/HTTP reachability check), refactored to take a host
   list directly and report each result the instant it lands.
3. `chaos_org/pipeline.py` — chains Stage 1 into Stage 2 (the existing
   `sni_core.py` SSL/SNI tunnel test). The moment a host clears Stage 1 it's
   handed straight to Stage 2's thread pool — it does **not** wait for the
   rest of the batch. A toggle lets you switch to fully sequential (Stage 1
   finishes completely, then Stage 2 starts).

**sublist3r.py patch:** the original hard-crashes on import if the `subbrute`
folder isn't present (it's a separate bundle not included in your upload).
I wrapped that import in a try/except — bruteforce mode just gets skipped
with a warning if unavailable, everything else (all the search-engine /
passive-source enumeration, which is the part you actually asked to run
against multiple sites) works unchanged.

**Two GUI options, same backend:**

- **`dashboard.html`** — the existing chaos_org cyan-themed dashboard, now
  with a "Recon" tab holding both the Subdomain Finder and the Live
  Pipeline (same feature set as below).
- **`recon.html`** — your actual subdomain finder page (see above),
  extended with multi-domain support and the Live Pipeline sub-nav.

Both give you:
- **Subdomain Finder** — Single Site / Paste Multiple / Upload File, threads
  + "domains at once" config, sequential toggle, optional custom result
  filename, live per-domain feed, results list with file paths.
- **Live Pipeline** — Upload File / Single Host / From Results / Paste
  Multiple, Stage 1 & Stage 2 worker counts, a "chain live vs sequential"
  toggle, two side-by-side live feeds (Stage 1 / Stage 2), and a bottom
  **Live Working Results** panel with filters (All / Stage 1 only /
  Confirmed both / Stage 2 tested) plus a named "Save this filter" button.
- Responsive breakpoints for tablet (~700–1099px), PC (≥1100px, opens
  a two-column layout), and large/TV displays (≥1600px, scales up type and
  spacing for viewing at a distance over the hotspot browser).

## Why `recon.html` is self-contained (doesn't reuse techwarlords.css)

`subdomain-finder.html` pulls in `techwarlords.css`, `techwarlords-core.js`,
and `ads.js` — none of which were in your upload, and all of which assume
you're on the live site (site-wide nav links to `index.html`/`apps.html`/etc,
ad slots, the site's own matrix-rain implementation). Since this is a
standalone Termux tool with no site around it, I rebuilt just the visual
language it needs (the red/black palette, fonts, terminal/hero/stat-card
look, and a matrix rain canvas) directly into `recon.html`, and dropped the
preloader, nav icon, and bottom site nav entirely, since none of those make
sense outside the live site.

## What I didn't touch, and why

Covered above in the `recon.html` section — the preloader and nav icon are
gone; the ad slot, back-link, and site nav were trimmed since they don't
resolve to anything in a standalone package (say the word if you want them
wired back up for the live site).

## Running it (Termux)

```
pip install -r requirements.txt --break-system-packages
python3 main.py          # same entry point as before — GUI mode launches
                          # gui_server.py, prints the LAN URLs to open
```

Open the printed `http://<phone-ip>:8000/dashboard.html` URL on your tablet
over the hotspot, same as before — the new Recon tab is just there. Or open
`http://<phone-ip>:8000/recon.html` for the TECH WARLORDS-skinned standalone
version — both talk to the same backend, so results/scans started from one
show up in the other's "From Results" picker too.

Bruteforce subdomain mode needs the `subbrute/` folder (names.txt +
resolvers.txt) sitting next to `sublist3r.py` — it's not bundled here. Passive
enumeration (crt.sh-style sources sublist3r already talks to) needs no extra
setup beyond `pip install -r requirements.txt`.
