const fetch = require('node-fetch'); // for Netlify

const USERNAME = 'ethanchaos';
const REPO = 'Test-3';
const PATH = 'uploads';
const TOKEN = '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'; // your PAT

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 200, body: 'Uploader is working!' };
  }

  try {
    const body = event.body;
    if (!body) return { statusCode: 400, body: 'No file uploaded' };

    // Base64 content from client
    const content = Buffer.from(body, 'base64').toString('base64');

    // Filename from header
    const fileName = event.headers['file-name'] || `file-${Date.now()}.txt`;

    const url = `https://api.github.com/repos/${USERNAME}/${REPO}/contents/${PATH}/${fileName}`;

    const res = await fetch(url, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: `Upload ${fileName} via Netlify`,
        content: content
      })
    });

    const data = await res.json();

    if (res.status >= 400) {
      return { statusCode: res.status, body: JSON.stringify(data) };
    }

    return { statusCode: 200, body: `File uploaded: ${fileName}` };

  } catch (err) {
    return { statusCode: 500, body: `Error: ${err.message}` };
  }
};